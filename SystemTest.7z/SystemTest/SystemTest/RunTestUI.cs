﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class RunTestUI : Form
    {
        public RunTestUI()
        {
            InitializeComponent();
            txtStatus.Text = "No selection";
            lblStatusBar.Text = string.Empty;
        }

        /// <summary>
        /// Set the Current selection menu items
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void slMenu_SelectedIndexChanged(object sender, EventArgs e)
        {

            int index = slMenu.SelectedIndex;

            switch (index)
            {
                case 0:
                    txtID.Text = "Selection 1";
                    txtStatus.Text = "Completed";
                    break;
                case 1:
                    txtID.Text = "Selection 2";
                    txtStatus.Text = "Not Executed";
                    break;
                case 2:
                    txtID.Text = "Selection 3";
                    txtStatus.Text = "Failed";
                    break;
                default:
                    txtStatus.Text = "No selection";
                    lblStatusBar.Text = string.Empty;
                    break;
            }

            LongListSectionEvents(sender);
        }

        /// <summary>
        /// Long the selected menu selection
        /// </summary>
        /// <param name="sender"></param>
        private void LongListSectionEvents(object sender)
        {
            var listBox = sender as ListBox;
            if (listBox.SelectedIndex >= 0)
            {
                lblLog.Text += $"Select {listBox.SelectedItem} \n";
                lblStatusBar.Text = listBox.SelectedItem.ToString();
            }
            else
            {
                lblStatusBar.Text = string.Empty;
            }
        }

        /// <summary>
        /// Log the perrses buttoun event 
        /// </summary>
        /// <param name="sender"></param>
        private void LongButtounSectionEvents(object sender)
        {
            var btn = sender as Button;
            lblLog.Text += $"press  {btn.Text} \n";
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (slMenu.SelectedIndex >= 0)
            {
                LongButtounSectionEvents(sender);
                ClearValues();
                slMenu.SelectedIndex = -1;
                txtStatus.Text = "No selection";
                lblStatusBar.Text = string.Empty;
            }
            else
            {
                MessageBox.Show("Alredy Canceled...! Nothing to Cancel");
            }
        }

        private void btnRunTest_Click(object sender, EventArgs e)
        {
            if (slMenu.SelectedIndex >= 0)
            {
                LongButtounSectionEvents(sender);
                PrintResult();
            }
            else
            {
                MessageBox.Show("Please select the selection to Run the Test");
            }
        }

        private void btnClearResults_Click(object sender, EventArgs e)
        {
            if (slMenu.SelectedIndex >= 0)
            {
                LongButtounSectionEvents(sender);
                ClearValues();
            }
            else
            {
                MessageBox.Show("Alredy Cleaned...! Nothing to Clear");
            }
        }

        /// <summary>
        /// Print the result based on selection 
        /// </summary>
        private void PrintResult()
        {
            switch (slMenu.SelectedIndex)
            {
                case 0:
                    lblResult.BackColor = Color.Green;
                    lblResult.Text = $"Send message: OK \n Receive Ack: OK \n  Receive message: OK \n All mandatory fields: OK \n Validating fields: OK ";
                    break;
                case 1:
                    lblResult.BackColor = Color.Black;
                    lblResult.Text = $"Not Executed ";
                    lblResult.ForeColor = Color.White;
                    break;
                case 2:
                    lblResult.BackColor = Color.Red;
                    lblResult.Text = $"Send message: OK \n Receive Ack: OK\n Receive message: OK\n All mandatory fields: Missing 2 fields\n Validating fields:\n Field ID 1 contains invalid info.\n Field ID 2 is missing.\n Field ID 5 is missing.";
                    break;
                default:
                    txtStatus.Text = "No selection";
                    break;
            }

        }

        /// <summary>
        /// Clreat the Values
        /// </summary>
        private void ClearValues()
        {
            txtID.Text = lblResult.Text = txtStatus.Text = string.Empty; ;
            txtStatus.Enabled = false;
            txtID.Enabled = false;
        }
    }
}
